
public class PercolationStats {


   public PercolationStats(int N, int T){
   }// perform T independent computational experiments on an N-by-N grid
   public double mean()   {
	   double x = 2.0;
	   return x;
   }// sample mean of percolation threshold
   public double stddev()  {
	   return 2.0;
   }// sample standard deviation of percolation threshold
   public double confidenceLo() {
	   return 2.0;
   }// returns lower bound of the 95% confidence interval
   public double confidenceHi() {
	   return 2.0;
   }// returns upper bound of the 95% confidence interval
   public static void main(String[] args) {
	   // test client, described below
}
	
	
}
